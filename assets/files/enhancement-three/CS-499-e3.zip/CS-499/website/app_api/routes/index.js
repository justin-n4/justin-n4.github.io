const express = require("express");
const router = express.Router();

const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");

// auth
router.route("/register").post(authController.register);
router.route("/login").post(authController.login);

// /api/trips
router
  .route("/trips")
  .get(tripsController.tripsList)
  .post(tripsController.authenticateJWT, tripsController.tripsAddTrip);

// /api/trips/:tripCode
router
  .route("/trips/:tripCode")
  .get(tripsController.tripsFindByCode)
  .put(tripsController.authenticateJWT, tripsController.tripsUpdateTrip)
  .delete(tripsController.authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;

