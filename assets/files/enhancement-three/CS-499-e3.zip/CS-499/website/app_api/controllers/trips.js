const mongoose = require("mongoose");
require("../models/travlr");

const { expressjwt: jwt } = require("express-jwt");

// protect write operations with JWT auth.
const authenticateJWT = jwt({
  secret: process.env.JWT_SECRET,
  algorithms: ["HS256"],
});

const Trip = mongoose.model("trips");

// allowed fields for trips create and update operations.
const TRIP_FIELDS = [
  "code",
  "name",
  "length",
  "start",
  "resort",
  "perPerson",
  "image",
  "description",
];

// keep only the fields that belong in the Trip document.
const extractTripData = (body = {}) => {
  return TRIP_FIELDS.reduce((tripData, field) => {
    if (body[field] !== undefined) {
      tripData[field] = body[field];
    }
    return tripData;
  }, {});
};

// validate trip codes before querying the DB.
const isValidTripCode = (tripCode = "") => {
  return typeof tripCode === "string" && /^[A-Z0-9-]+$/i.test(tripCode.trim());
};

// format schema validation errors into a cleaner array of messages.
const formatValidationErrors = (err) => {
  return Object.values(err.errors || {}).map((error) => error.message);
};

// centralize API error responses for consistent controller output.
const sendTripError = (res, status, message, details = null) => {
  const payload = { message };
  if (details) {
    payload.details = details;
  }
  return res.status(status).json(payload);
};

// GET all trips.
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({})
      .sort({ start: 1, name: 1 })
      .lean()
      .exec();

    return res.status(200).json(trips);
  } catch (err) {
    return sendTripError(res, 500, "Unable to retrieve trips", err.message);
  }
};

// GET one trip by code.
const tripsFindByCode = async (req, res) => {
  const tripCode = req.params.tripCode?.trim().toUpperCase();

  if (!isValidTripCode(tripCode)) {
    return sendTripError(res, 400, "A valid trip code is required");
  }

  try {
    const trip = await Trip.findOne({ code: tripCode }).lean().exec();

    if (!trip) {
      return sendTripError(res, 404, "Trip not found");
    }

    return res.status(200).json(trip);
  } catch (err) {
    return sendTripError(res, 500, "Unable to retrieve trip", err.message);
  }
};

// POST create trip.
const tripsAddTrip = async (req, res) => {
  const tripData = extractTripData(req.body);

  if (tripData.code) {
    tripData.code = tripData.code.trim().toUpperCase();
  }

  try {
    const trip = await Trip.create(tripData);
    return res.status(201).json(trip);
  } catch (err) {
    if (err.code === 11000) {
      return sendTripError(res, 409, "A trip with that code already exists");
    }

    if (err.name === "ValidationError") {
      return sendTripError(res, 400, "Invalid trip data", formatValidationErrors(err));
    }

    return sendTripError(res, 500, "Unable to create trip", err.message);
  }
};

// PUT update trip.
const tripsUpdateTrip = async (req, res) => {
  const tripCode = req.params.tripCode?.trim().toUpperCase();

  if (!isValidTripCode(tripCode)) {
    return sendTripError(res, 400, "A valid trip code is required");
  }

  const updates = extractTripData(req.body);

  if (updates.code) {
    updates.code = updates.code.trim().toUpperCase();
  }

  if (Object.keys(updates).length === 0) {
    return sendTripError(res, 400, "No update fields were provided");
  }

  try {
    const trip = await Trip.findOne({ code: tripCode }).exec();

    if (!trip) {
      return sendTripError(res, 404, "Trip not found");
    }
    
    // merge the allowed incoming fields into the existing doc. 
    Object.assign(trip, updates);

    const updatedTrip = await trip.save();
    return res.status(200).json(updatedTrip);
  } catch (err) {
    if (err.code === 11000) {
      return sendTripError(res, 409, "A trip with that code already exists");
    }

    if (err.name === "ValidationError") {
      return sendTripError(res, 400, "Invalid trip data", formatValidationErrors(err));
    }

    return sendTripError(res, 500, "Unable to update trip", err.message);
  }
};

// DELETE trip.
const tripsDeleteTrip = async (req, res) => {
  const tripCode = req.params.tripCode?.trim().toUpperCase();

  if (!isValidTripCode(tripCode)) {
    return sendTripError(res, 400, "A valid trip code is required");
  }

  try {
    const result = await Trip.deleteOne({ code: tripCode }).exec();

    if (result.deletedCount === 0) {
      return sendTripError(res, 404, "Trip not found");
    }

    return res.status(204).send();
  } catch (err) {
    return sendTripError(res, 500, "Unable to delete trip", err.message);
  }
};

module.exports = {
  authenticateJWT,
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
};
