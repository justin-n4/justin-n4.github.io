const TRIPS_API_URL = process.env.TRIPS_API_URL || "http://localhost:3000/api/trips";

// Build a consistent view model for the travel page. This keeps the data shape predictable whether the page loads normally, the database is empty, or the API request fails.

const buildTravelViewModel = (trips = [], message = null) => ({
  title: "Travlr Getaways",
  trips,
  message,
});

// Render the public travel page by requesting trip data from the API layer. The endpoint is environment-based rather than hard-coded directly in the function.
const travel = async (req, res) => {
  try {
    const response = await fetch(TRIPS_API_URL, {
      method: "GET",
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      throw new Error(`Trips API returned status ${response.status}`);
    }

    const trips = await response.json();

    if (!Array.isArray(trips)) {
      return res.render(
        "travel",
        buildTravelViewModel([], "Trip data is unavailable right now. Please try again later.")
      );
    }

    if (trips.length === 0) {
      return res.render(
        "travel",
        buildTravelViewModel([], "No trips exist in our database.")
      );
    }

    return res.render("travel", buildTravelViewModel(trips));
  } catch (err) {
    console.error("Error loading travel page:", err.message);

    return res.render(
      "travel",
      buildTravelViewModel(
        [],
        "We’re having trouble loading trips right now. Please try again later."
      )
    );
  }
};

module.exports = { travel };
