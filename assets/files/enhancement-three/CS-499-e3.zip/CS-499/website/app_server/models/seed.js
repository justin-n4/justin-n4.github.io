const mongoose = require('./db');
const Trip = require('./travlr');

// seed data from JSON
const fs = require('fs');
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

// deletes records and inserts seed data
const seedDB = async () => {
  await Trip.deleteMany({});
  await Trip.insertMany(trips);
};

seedDB().then(async () => {
  await mongoose.connection.close();
  process.exit(0);
});
