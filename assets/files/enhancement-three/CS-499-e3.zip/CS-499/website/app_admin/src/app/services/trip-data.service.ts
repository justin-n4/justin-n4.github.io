import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Trip {
  _id?: string;
  code: string;
  name: string;
  length: string;
  start: string;
  resort: string;
  perPerson: string;
  image: string;
  description: string;
}

@Injectable({ providedIn: 'root' })
export class TripDataService {
  private readonly baseUrl = '/api/trips';

  constructor(private http: HttpClient) {}

  // Attach the stored JWT to protected write requests.
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('travlr-token') || '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  // Retrieve the full list of trips.
  getTrips(): Observable<Trip[]> {
    return this.http
      .get<Trip[]>(this.baseUrl)
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Retrieve one trip by its trip code.
  getTrip(tripCode: string): Observable<Trip> {
    return this.http
      .get<Trip>(`${this.baseUrl}/${tripCode}`)
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Send a new trip to the API for creation.
  addTrip(trip: Trip): Observable<Trip> {
    return this.http
      .post<Trip>(this.baseUrl, trip, { headers: this.getAuthHeaders() })
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Update an existing trip by code.
  updateTrip(tripCode: string, trip: Trip): Observable<Trip> {
    return this.http
      .put<Trip>(`${this.baseUrl}/${tripCode}`, trip, { headers: this.getAuthHeaders() })
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Delete a trip by code.
  deleteTrip(tripCode: string): Observable<void> {
    return this.http
      .delete<void>(`${this.baseUrl}/${tripCode}`, { headers: this.getAuthHeaders() })
      .pipe(catchError((error) => this.handleError(error)));
  }

  // Centralize API error handling so components don't repeat the same logic.
  private handleError(error: HttpErrorResponse) {
    const message =
      error.error?.message ||
      error.error?.details?.join(', ') ||
      'An unexpected error occurred while processing trip data.';

    return throwError(() => new Error(message));
  }
}