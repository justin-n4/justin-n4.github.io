import { Routes } from '@angular/router';
import { TripListingComponent } from './trip-listing/trip-listing.component';
import { TripAddComponent } from './trip-add/trip-add.component';
import { TripEditComponent } from './trip-edit/trip-edit.component';

export const routes: Routes = [
  { path: '', component: TripListingComponent },
  { path: 'add', component: TripAddComponent },
  { path: 'edit/:tripCode', component: TripEditComponent },
];

