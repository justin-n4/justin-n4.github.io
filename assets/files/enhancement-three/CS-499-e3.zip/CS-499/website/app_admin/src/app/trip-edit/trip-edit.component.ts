import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { TripDataService, Trip } from '../services/trip-data.service';

@Component({
  selector: 'app-trip-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-edit.component.html'
})
export class TripEditComponent implements OnInit {
  tripCode = '';
  trip: Trip | null = null;
  errorMessage = '';
  successMessage = '';
  isLoading = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit(): void {
    // Route for the current trip code and load the matching trip.
    this.route.paramMap.subscribe({
      next: (params: ParamMap) => {
        this.tripCode = params.get('tripCode') || '';

        if (!this.tripCode) {
          this.errorMessage = 'Trip code is missing.';
          this.trip = null;
          return;
        }

        this.loadTrip();
      }
    });
  }

  // Load the selected trip and update the component state.
  loadTrip(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.tripService.getTrip(this.tripCode).subscribe({
      next: (data) => {
        this.trip = data;
        this.isLoading = false;
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
        this.trip = null;
        this.isLoading = false;
      },
    });
  }

  // Save any edits made to the current trip.
  onSave(): void {
    if (!this.trip) {
      this.errorMessage = 'Trip data is unavailable.';
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';

    this.tripService.updateTrip(this.tripCode, this.trip).subscribe({
      next: () => {
        this.successMessage = 'Trip updated successfully.';
        this.router.navigate(['/']);
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
      },
    });
  }

  // Delete the current trip and return to the main page.
  onDelete(): void {
    if (!this.tripCode) {
      this.errorMessage = 'Trip code is missing.';
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';

    this.tripService.deleteTrip(this.tripCode).subscribe({
      next: () => {
        this.successMessage = 'Trip deleted successfully.';
        this.router.navigate(['/']);
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
      },
    });
  }
}
