import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDataService, Trip } from '../services/trip-data.service';

@Component({
  selector: 'app-trip-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-edit.component.html'
})
export class TripEditComponent implements OnInit {
  tripCode = '';
  trip!: Trip;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit(): void {
    this.tripCode = this.route.snapshot.paramMap.get('tripCode') || '';
    this.tripService.getTrip(this.tripCode).subscribe({
      next: (data) => (this.trip = data),
      error: (err) => console.error(err),
    });
  }

  onSave(): void {
    this.tripService.updateTrip(this.tripCode, this.trip).subscribe({
      next: () => this.router.navigate(['/']),
      error: (err) => console.error(err),
    });
  }

  onDelete(): void {
    this.tripService.deleteTrip(this.tripCode).subscribe({
      next: () => this.router.navigate(['/']),
      error: (err) => console.error(err),
    });
  }
}

