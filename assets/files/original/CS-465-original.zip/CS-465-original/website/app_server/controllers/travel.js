/* GET travel page */
const travel = async (req, res) => {
  const tripsEndpoint = "http://localhost:3000/api/trips";
  const options = {
    method: "GET",
    headers: { Accept: "application/json" },
  };

  try {
    const response = await fetch(tripsEndpoint, options);
    const trips = await response.json();

    let message = null;
    if (!Array.isArray(trips)) {
      message = "API lookup error";
    } else if (trips.length === 0) {
      message = "No trips exist in our database.";
    }

    res.render("travel", { title: "Travlr Getaways", trips, message });
  } catch (err) {
    res.status(500).send(err.message);
  }
};

module.exports = { travel };
