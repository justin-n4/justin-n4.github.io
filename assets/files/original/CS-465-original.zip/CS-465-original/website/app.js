require("dotenv").config();

const express = require("express");
const path = require("path");
const hbs = require("hbs");
const passport = require("passport");

require("./app_api/models/db");
require("./app_api/config/passport");

const indexRouter = require("./app_server/routes/index");
const travelRouter = require("./app_server/routes/travel");
const apiRouter = require("./app_api/routes/index");

const app = express();
const PORT = process.env.PORT || 3000;

// CORS 
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "http://localhost:4200"); 
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// body parse
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// passport init 
app.use(passport.initialize());

// view engine setup
app.set("views", path.join(__dirname, "app_server", "views"));
app.set("view engine", "hbs");
hbs.registerPartials(path.join(__dirname, "app_server", "views", "partials"));

// static assets
app.use(express.static(path.join(__dirname, "public"), { index: false }));

// routes
app.use("/", indexRouter);
app.use("/travel", travelRouter);
app.use("/api", apiRouter);

// auth error 
app.use((err, req, res, next) => {
  if (err.name === "UnauthorizedError") {
    return res.status(401).json({ message: `${err.name}: ${err.message}` });
  }
  next(err);
});

app.listen(PORT, () => {
  console.log(`Express server running at http://localhost:${PORT}`);
});
