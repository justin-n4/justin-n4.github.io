const mongoose = require("mongoose");
require("../models/travlr");

const { expressjwt: jwt } = require("express-jwt");

const authenticateJWT = jwt({
  secret: process.env.JWT_SECRET,
  algorithms: ["HS256"],
});

const Trip = mongoose.model("trips");

// GET
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();
    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: "No trips found" });
    }
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json(err);
  }
};

// GET
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) return res.status(404).json({ message: "Trip not found" });
    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json(err);
  }
};

// POST
const tripsAddTrip = async (req, res) => {
  try {
    const trip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description,
    });
    return res.status(201).json(trip);
  } catch (err) {
    return res.status(400).json(err);
  }
};

// PUT
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) return res.status(404).json({ message: "Trip not found" });

    trip.code = req.body.code ?? trip.code;
    trip.name = req.body.name ?? trip.name;
    trip.length = req.body.length ?? trip.length;
    trip.start = req.body.start ?? trip.start;
    trip.resort = req.body.resort ?? trip.resort;
    trip.perPerson = req.body.perPerson ?? trip.perPerson;
    trip.image = req.body.image ?? trip.image;
    trip.description = req.body.description ?? trip.description;

    const updated = await trip.save();
    return res.status(200).json(updated);
  } catch (err) {
    return res.status(400).json(err);
  }
};

// DELETE
const tripsDeleteTrip = async (req, res) => {
  try {
    const result = await Trip.deleteOne({ code: req.params.tripCode }).exec();
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: "Trip not found" });
    }
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json(err);
  }
};

module.exports = {
  authenticateJWT,
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
};
